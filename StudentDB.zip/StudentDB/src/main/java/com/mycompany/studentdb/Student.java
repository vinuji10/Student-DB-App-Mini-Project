package com.mycompany.studentdb;

import java.sql.Date;   // Import for SQL Date

public class Student {
    private int id;
    private String name;
    private String grade;
    private Date dob;
    private String subject;

    public Student(int id, String name, String grade, Date dob, String subject) {
        this.id = id;
        this.name = name;
        this.grade = grade;
        this.dob = dob;
        this.subject = subject;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }


    @Override
    public String toString() {
        return String.format(
            "+--------+----------------------+-------+------------+----------------------+\n" +
            "| ID     | Name                 | Grade | DOB        | Subject              |\n" +
            "+--------+----------------------+-------+------------+----------------------+\n" +
            "| %-6d | %-20s | %-5s | %-10s | %-20s |\n" +
            "+--------+----------------------+-------+------------+----------------------+\n",
            id,
            name,
            grade,
            dob != null ? dob.toString() : "",
            subject
        );
    }
}