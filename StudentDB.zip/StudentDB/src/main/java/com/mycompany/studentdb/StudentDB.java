/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.studentdb;
import java.sql.*;
/**
 *
 * @author LENOVO
 */
public class StudentDB {
public static void main(String[] args) {
        try (Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/testdb", "root", "1234")) {
            
//            con.setAutoCommit(false); // start transaction
//            
//            Statement stmt = con.createStatement();
//            stmt.executeUpdate("INSERT INTO students (name, age) VALUES ('Carol', 21)");
//            stmt.executeUpdate("UPDATE students SET age=22 WHERE name='Bob'");
//            
//            con.commit(); // commit transaction
            System.out.println("Transaction committed.");
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        
    }
}